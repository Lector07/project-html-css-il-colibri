package com.example.libraryproject.controllers;

import com.example.libraryproject.config.HibernateConfig;
import com.example.libraryproject.models.Author;
import com.example.libraryproject.models.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.io.IOException;
import java.util.List;

import static com.example.libraryproject.utils.AlertUtil.showAlert;

public class AuthorsController {

    @FXML
    private Button addAuthorButton;

    @FXML
    private Button updateAuthorButton;

    @FXML
    private Button deleteAuthorButton;

    @FXML
    private Button backToDashboard;

    private User loggedUser;

    @FXML
    private Label loggedUserLabel;

    @FXML
    private TableView<Author> authorsTableView;

    @FXML
    private TableColumn<Author, Integer> columnId;

    @FXML
    private TableColumn<Author, String> columnFirstName;

    @FXML
    private TableColumn<Author, String> columnLastName;

    @FXML
    private TableColumn<Author, String> columnCountry;

    private SessionFactory sessionFactory;
    private ObservableList<Author> authorsList;

    @FXML
    public void initialize() {
        sessionFactory = HibernateConfig.getSessionFactory();

        authorsList = FXCollections.observableArrayList();
        authorsTableView.setItems(authorsList);

        columnId.setCellValueFactory(new PropertyValueFactory<>("id"));
        columnFirstName.setCellValueFactory(new PropertyValueFactory<>("firstname"));
        columnLastName.setCellValueFactory(new PropertyValueFactory<>("lastname"));
        columnCountry.setCellValueFactory(new PropertyValueFactory<>("country"));

        loadAuthorsFromDatabase();

        addAuthorButton.setOnAction(event -> openAuthorAddWindow());
        updateAuthorButton.setOnAction(event -> openAuthorEditWindow());
        deleteAuthorButton.setOnAction(event -> deleteAuthor());
    }

    public void setLoggedUser(User loggedUser) {
        this.loggedUser = loggedUser;
        updateLoggedUserLabel();
    }

    private void updateLoggedUserLabel() {
        if (loggedUser != null) {
            loggedUserLabel.setText("Zalogowany: " + loggedUser.getUsername());
        } else {
            loggedUserLabel.setText("User: Guest");
        }
    }

    private void loadAuthorsFromDatabase() {
        try (Session session = sessionFactory.openSession()) {
            List<Author> authors = session.createQuery("FROM Author", Author.class).list();
            authorsList.setAll(authors);
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error loading authors", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void refreshTable() {
        authorsTableView.getItems().clear(); // Wyczyść istniejące elementy tabeli
        try (Session session = sessionFactory.openSession()) {
            List<Author> authors = session.createQuery("FROM Author", Author.class).list(); // Pobierz wszystkich autorów
            authorsTableView.getItems().addAll(authors); // Dodaj zaktualizowane dane
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się odświeżyć tabeli autorów.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void openAuthorAddWindow() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/authorAdd.fxml"));
            Parent root = loader.load();

            AuthorAddController authorAddController = loader.getController();
            authorAddController.setSessionFactory(sessionFactory);
            authorAddController.setLoggedUser(loggedUser);

            Stage stage = new Stage();
            stage.initOwner(addAuthorButton.getScene().getWindow());
            stage.setTitle("Dodaj autora");
            stage.setScene(new Scene(root));
            stage.setResizable(false);
            stage.showAndWait();
            refreshTable();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się otworzyć okna 'Dodaj autora'.", Alert.AlertType.ERROR);
        }
    }

    private void openAuthorEditWindow() {
        Author selectedAuthor = authorsTableView.getSelectionModel().getSelectedItem();
        if (selectedAuthor == null) {
            showAlert("Nie wybrano autora", "Aby edytować, proszę wybrać autora z tabeli.", Alert.AlertType.WARNING);
            return;
        }
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/authorEdit.fxml"));
            Parent root = loader.load();

            AuthorEditController authorEditController = loader.getController();
            authorEditController.setSessionFactory(sessionFactory);
            authorEditController.setLoggedUser(loggedUser);
            authorEditController.setAuthorToEdit(selectedAuthor);
            Stage stage = new Stage();
            stage.initOwner(updateAuthorButton.getScene().getWindow());
            stage.setTitle("Edytuj autora");
            stage.setScene(new Scene(root));
            stage.setResizable(false);
            stage.showAndWait();
            refreshTable();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się otworzyć okna 'Edytuj autora'.", Alert.AlertType.ERROR);
        }
    }

    private void deleteAuthor() {
        Author selectedAuthor = authorsTableView.getSelectionModel().getSelectedItem();
        if (selectedAuthor == null) {
            showAlert("Nie wybrano autora", "Proszę wybrać autora do usunięcia!", Alert.AlertType.WARNING);
            return;
        }

        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmationAlert.setTitle("Potwierdzenie usunięcia");
        confirmationAlert.setHeaderText(null);
        confirmationAlert.setContentText("Czy na pewno chcesz usunąć wybranego autora?");
        ButtonType yesButton = new ButtonType("Tak", ButtonBar.ButtonData.YES);
        ButtonType noButton = new ButtonType("Nie", ButtonBar.ButtonData.NO);
        confirmationAlert.getButtonTypes().setAll(yesButton, noButton);

        confirmationAlert.showAndWait().ifPresent(response -> {
            if (response == yesButton) {
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();

                    session.delete(selectedAuthor);
                    transaction.commit();

                    authorsList.remove(selectedAuthor);
                } catch (Exception e) {
                    e.printStackTrace();
                    showAlert("Błąd usunięcia autora", e.getMessage(), Alert.AlertType.ERROR);
                }
            }
        });
    }

    @FXML
    private void goBackToDashboard() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/dashboard.fxml"));
            Parent dashboardRoot = loader.load();

            DashboardController dashboardController = loader.getController();
            dashboardController.setLoggedUser(loggedUser);

            Stage currentStage = (Stage) backToDashboard.getScene().getWindow();
            Scene dashboardScene = new Scene(dashboardRoot);
            currentStage.setScene(dashboardScene);
            currentStage.setTitle("Panel główny");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Nie udało się załadować widoku Dashboard.", Alert.AlertType.ERROR);
        }
    }
}