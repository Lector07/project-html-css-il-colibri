package com.example.libraryproject.controllers;

import com.example.libraryproject.models.Book;
import com.example.libraryproject.models.BorrowedBook;
import com.example.libraryproject.models.User;
import com.example.libraryproject.utils.AlertUtil;
import com.example.libraryproject.utils.HibernateUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import static com.example.libraryproject.utils.AlertUtil.showAlert;

public class BorrowBookController {

    @FXML
    private Button backToDashboard;

    @FXML
    private TableView<Book> booksTableView;

    @FXML
    private TableColumn<Book, Long> idColumn;

    @FXML
    private TableColumn<Book, String> titleColumn;

    @FXML
    private TableColumn<Book, String> authorColumn;

    @FXML
    private TableColumn<Book, Integer> yearColumn;

    @FXML
    private TableColumn<Book, Integer> copiesColumn;

    private User loggedUser;

    @FXML
    public void initialize() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        authorColumn.setCellValueFactory(new PropertyValueFactory<>("author"));
        yearColumn.setCellValueFactory(new PropertyValueFactory<>("year"));
        copiesColumn.setCellValueFactory(new PropertyValueFactory<>("copies"));
        loadBooks();
    }

    public void setLoggedUser(User loggedUser) {
        this.loggedUser = loggedUser;
    }

    private void loadBooks() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            List<Book> books = session.createQuery("FROM Book", Book.class).list();
            ObservableList<Book> booksList = FXCollections.observableArrayList(books);
            booksTableView.setItems(booksList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void borrowBook() {
        Book selectedBook = booksTableView.getSelectionModel().getSelectedItem();
        if (selectedBook == null) {
            AlertUtil.showAlert("Błąd", "Proszę wybrać książkę do wypożyczenia!", Alert.AlertType.ERROR);
            return;
        }

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();

            // Check if the user has already borrowed this book
            BorrowedBook existingBorrow = session.createQuery("FROM BorrowedBook WHERE user = :user AND book = :book", BorrowedBook.class)
                    .setParameter("user", loggedUser)
                    .setParameter("book", selectedBook)
                    .uniqueResult();

            if (existingBorrow != null) {
                AlertUtil.showAlert("Błąd", "Już wypożyczyłeś tę książkę!", Alert.AlertType.ERROR);
                return;
            }

            if (selectedBook.getCopies() <= 0) {
                AlertUtil.showAlert("Błąd", "Brak dostępnych kopii tej książki!", Alert.AlertType.ERROR);
                return;
            }

            LocalDate borrowDate = LocalDate.now();
            LocalDate returnDate = borrowDate.plusMonths(1);

            BorrowedBook borrowedBook = new BorrowedBook(loggedUser, selectedBook, borrowDate, returnDate);
            session.save(borrowedBook);

            selectedBook.setCopies(selectedBook.getCopies() - 1);
            session.update(selectedBook);

            transaction.commit();

            AlertUtil.showAlert("Sukces", "Książka została pomyślnie wypożyczona!", Alert.AlertType.INFORMATION);
            loadBooks();
        } catch (Exception e) {
            e.printStackTrace();
            AlertUtil.showAlert("Błąd", "Wystąpił problem podczas wypożyczania książki.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void goBackToDashboard() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/dashboard.fxml"));
            Parent dashboardRoot = loader.load();

            DashboardController dashboardController = loader.getController();
            dashboardController.setLoggedUser(loggedUser);

            Stage currentStage = (Stage) backToDashboard.getScene().getWindow();
            Scene dashboardScene = new Scene(dashboardRoot);
            currentStage.setScene(dashboardScene);
            currentStage.setTitle("Panel główny");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się załadować widoku Dashboard.", Alert.AlertType.ERROR);
        }
    }
}