package com.example.libraryproject.controllers;

import com.example.libraryproject.models.User;
import com.example.libraryproject.utils.AlertUtil;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button loginButton;

    private SessionFactory sessionFactory;

    public LoginController() {
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");
        configuration.addAnnotatedClass(User.class);
        sessionFactory = configuration.buildSessionFactory();
    }

    @FXML
    public void initialize() {
        loginButton.setOnAction(event -> loginUser());
    }

    @FXML
    private void loginUser() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        if (username.isEmpty() || password.isEmpty()) {
            AlertUtil.showAlert("Błąd walidacji", "Oba pola są wymagane!", Alert.AlertType.WARNING);
            return;
        }

        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = null;

            try {
                transaction = session.beginTransaction();

                String hql = "FROM User WHERE username = :username";
                User user = (User) session.createQuery(hql)
                        .setParameter("username", username)
                        .uniqueResult();

                if (user == null) {
                    AlertUtil.showAlert("Błąd logowania", "Nie znaleziono użytkownika o podanej nazwie!", Alert.AlertType.ERROR);
                } else if (!user.getPassword().equals(password)) {
                    AlertUtil.showAlert("Błąd logowania", "Nieprawidłowe hasło!", Alert.AlertType.ERROR);
                } else {
                    AlertUtil.showAlert("Logowanie pomyślne", "Zalogowano pomyślnie!", Alert.AlertType.INFORMATION);
                    transaction.commit();

                    switchToDashboard(user);
                }
            } catch (Exception e) {
                if (transaction != null) {
                    transaction.rollback();
                }
                e.printStackTrace();
                AlertUtil.showAlert("Błąd", "Wystąpił błąd podczas logowania: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        }
    }

    private void switchToDashboard(User loggedUser) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/dashboard.fxml"));
            Scene dashboardScene = new Scene(fxmlLoader.load());

            DashboardController dashboardController = fxmlLoader.getController();

            dashboardController.setLoggedUser(loggedUser);

            Stage stage = (Stage) loginButton.getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.setTitle("Panel główny");
        } catch (IOException e) {
            e.printStackTrace();
            AlertUtil.showAlert("Błąd", "Nie udało się załadować panelu: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void switchToRegister() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/register.fxml"));
            Scene registerScene = new Scene(fxmlLoader.load());

            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.setScene(registerScene);
            stage.setTitle("Rejestracja");
        } catch (IOException e) {
            e.printStackTrace();
            AlertUtil.showAlert("Błąd", "Nie udało się załadować ekranu rejestracji: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }
}