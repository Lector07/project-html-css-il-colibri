package com.example.libraryproject.controllers;

import com.example.libraryproject.models.Author;
import com.example.libraryproject.models.Book;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import java.util.Calendar;
import java.util.List;

import static com.example.libraryproject.utils.AlertUtil.showAlert;

public class BookAddController {

    @FXML
    private TextField titleField;

    @FXML
    private TextField yearField;

    @FXML
    private TextField copiesField;

    @FXML
    private ComboBox<Author> authorComboBox;

    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
        loadAuthors();
    }

    private void loadAuthors() {
        try (Session session = sessionFactory.openSession()) {
            Query<Author> query = session.createQuery("FROM Author", Author.class);
            List<Author> authors = query.getResultList();
            ObservableList<Author> authorList = FXCollections.observableArrayList(authors);
            authorComboBox.setItems(authorList);
        } catch (Exception e) {
            showAlert("Błąd", "Nie udało się załadować listy autorów: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void saveBook() {
        String title = titleField.getText();
        String yearText = yearField.getText();
        String copiesText = copiesField.getText();
        Author selectedAuthor = authorComboBox.getValue();

        if (title.isEmpty() || yearText.isEmpty() || copiesText.isEmpty() || selectedAuthor == null) {
            showAlert("Błąd", "Wszystkie pola, w tym autor, muszą być wypełnione.", Alert.AlertType.ERROR);
            return;
        }

        try {
            int year = Integer.parseInt(yearText);
            int copies = Integer.parseInt(copiesText);
            int currentYear = Calendar.getInstance().get(Calendar.YEAR);

            if (year > currentYear) {
                showAlert("Błąd", "Rok nie może być wyższy niż bieżący rok.", Alert.AlertType.ERROR);
                return;
            }

            if (copies > 100) {
                showAlert("Błąd", "Liczba kopii nie może przekraczać 100.", Alert.AlertType.ERROR);
                return;
            }

            try (Session session = sessionFactory.openSession()) {
                session.beginTransaction();
                Book newBook = new Book();
                newBook.setTitle(title);
                newBook.setYear(year);
                newBook.setCopies(copies);
                newBook.setAuthor(selectedAuthor);
                session.save(newBook);
                session.getTransaction().commit();
            }

            showAlert("Sukces", "Książka została zapisana w bazie danych.", Alert.AlertType.INFORMATION);
            closeWindow();
        } catch (NumberFormatException e) {
            showAlert("Błąd", "Rok i liczba kopii muszą być liczbami całkowitymi.", Alert.AlertType.ERROR);
        } catch (Exception e) {
            showAlert("Błąd", "Wystąpił problem podczas zapisywania książki: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void closeWindow() {
        Stage stage = (Stage) titleField.getScene().getWindow();
        stage.close();
    }
}