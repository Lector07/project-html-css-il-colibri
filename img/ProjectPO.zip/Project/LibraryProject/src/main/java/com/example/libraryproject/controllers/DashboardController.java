package com.example.libraryproject.controllers;

import com.example.libraryproject.models.User;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class DashboardController {

    @FXML
    private Label loggedUserLabel;

    @FXML
    private Button booksButton;

    @FXML
    private Button authorsButton;

    @FXML
    private Button usersButton;

    @FXML
    private Button logoutButton;

    @FXML
    private Button myBooksButton;

    @FXML
    private Button borrowBookButton;

    private User loggedUser;

    @FXML
    public void initialize() {
        booksButton.setOnAction(event -> openBooksSection());
        authorsButton.setOnAction(event -> openAuthorsSection());
        usersButton.setOnAction(event -> openUsersSection());
        logoutButton.setOnAction(event -> logout());
        myBooksButton.setOnAction(event -> openMyBooksSection());
        borrowBookButton.setOnAction(event -> openBorrowBookSection());
    }

    @FXML
    public void setLoggedUser(User user) {
        this.loggedUser = user;
        updateLoggedUserLabel();
        updateButtonVisibility();
    }

    private void updateLoggedUserLabel() {
        if (loggedUser != null && loggedUser.getUsername() != null) {
            loggedUserLabel.setText("Zalogowany: " + loggedUser.getUsername());
        } else {
            loggedUserLabel.setText("User: Guest");
        }
    }

    private void updateButtonVisibility() {
        if (loggedUser != null && "admin".equals(loggedUser.getUsername())) {
            booksButton.setVisible(true);
            authorsButton.setVisible(true);
            usersButton.setVisible(true);
            myBooksButton.setVisible(false);
            borrowBookButton.setVisible(false);
        } else {
            booksButton.setVisible(false);
            authorsButton.setVisible(false);
            usersButton.setVisible(false);
            myBooksButton.setVisible(true);
            borrowBookButton.setVisible(true);
        }
    }

    @FXML
    private void openBooksSection() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/books.fxml"));
            Parent booksRoot = loader.load();

            BooksController booksController = loader.getController();
            booksController.setLoggedUser(loggedUser);

            Stage currentStage = (Stage) booksButton.getScene().getWindow();
            currentStage.setScene(new Scene(booksRoot));
            currentStage.setTitle("Panel książek");
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Nie udało się załadować widoku 'Panel książek'.:" + e.getMessage());

        }
    }

    private void openAuthorsSection() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/authors.fxml"));
            Parent authorsRoot = loader.load();

            AuthorsController authorsController = loader.getController();
            authorsController.setLoggedUser(loggedUser);

            Stage currentStage = (Stage) authorsButton.getScene().getWindow();
            Scene authorsScene = new Scene(authorsRoot);
            currentStage.setScene(authorsScene);
            currentStage.setTitle("Panel autorów");

        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Nie udało się załadować widoku 'Panel autorów':" + e.getMessage());
        }
    }

    private void openUsersSection() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/users.fxml"));
            Parent usersRoot = fxmlLoader.load();

            UsersController usersController = fxmlLoader.getController();
            usersController.setLoggedUser(loggedUser);

            Stage stage = (Stage) usersButton.getScene().getWindow();
            stage.setScene(new Scene(usersRoot));
            stage.setTitle("Panel użytkowników");
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Nie udało się załadować widoku 'Panel użytkownika':" + e.getMessage());
        }
    }

    private void openMyBooksSection() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/myBooks.fxml"));
            Parent myBooksRoot = loader.load();

            MyBooksController myBooksController = loader.getController();
            myBooksController.setLoggedUser(loggedUser);

            Stage currentStage = (Stage) myBooksButton.getScene().getWindow();
            currentStage.setScene(new Scene(myBooksRoot));
            currentStage.setTitle("Moje książki");
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Nie udało się załadować widoku 'Moje książki':" + e.getMessage());
        }
    }

    private void openBorrowBookSection() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/borrowBook.fxml"));
            Parent borrowBookRoot = loader.load();

            BorrowBookController borrowBookController = loader.getController();
            borrowBookController.setLoggedUser(loggedUser);

            Stage currentStage = (Stage) borrowBookButton.getScene().getWindow();
            currentStage.setScene(new Scene(borrowBookRoot));
            currentStage.setTitle("Wypożycz Książkę");
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Nie udało się załadować widoku 'Wypożycz Książkę'.");
        }
    }

    @FXML
    private void logout() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/login.fxml"));
            Scene loginScene = new Scene(fxmlLoader.load());

            Stage stage = (Stage) logoutButton.getScene().getWindow();
            stage.setScene(loginScene);
            stage.setTitle("Logowanie");
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Nie udało się załadować okna logowania: " + e.getMessage());
        }
    }
}