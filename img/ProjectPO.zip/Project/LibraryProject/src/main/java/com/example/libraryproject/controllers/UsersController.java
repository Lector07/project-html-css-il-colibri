package com.example.libraryproject.controllers;

import com.example.libraryproject.models.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.io.IOException;
import java.util.List;

import static com.example.libraryproject.utils.AlertUtil.showAlert;

public class UsersController {

    @FXML
    private Button addUserButton;

    @FXML
    private Button editUserButton;

    @FXML
    private Button deleteUserButton;

    @FXML
    private Button backToDashboard;

    private User loggedUser;

    @FXML
    private Label loggedUserLabel;

    @FXML
    private TableView<User> usersTableView;

    @FXML
    private TableColumn<User, Integer> idColumn;

    @FXML
    private TableColumn<User, String> usernameColumn;

    @FXML
    private TableColumn<User, String> emailColumn;

    @FXML
    private TableColumn<User, String> passwordColumn;

    private SessionFactory sessionFactory;
    private ObservableList<User> usersList;

    @FXML
    public void initialize() {
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");
        configuration.addAnnotatedClass(User.class);
        sessionFactory = configuration.buildSessionFactory();

        usersList = FXCollections.observableArrayList();
        usersTableView.setItems(usersList);

        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        passwordColumn.setCellValueFactory(new PropertyValueFactory<>("password"));

        loadUsersFromDatabase();

        addUserButton.setOnAction(event -> openUserAddWindow());
        editUserButton.setOnAction(event -> openUserEditWindow());
        deleteUserButton.setOnAction(event -> deleteUser());
    }

    public void setLoggedUser(User loggedUser) {
        this.loggedUser = loggedUser;
        updateLoggedUserLabel();
    }

    private void updateLoggedUserLabel() {
        if (loggedUser != null) {
            loggedUserLabel.setText("Zalogowany: " + loggedUser.getUsername());
        } else {
            loggedUserLabel.setText("User: Guest");
        }
    }

    private void loadUsersFromDatabase() {
        try (Session session = sessionFactory.openSession()) {
            List<User> users = session.createQuery("FROM User", User.class).list();
            usersList.setAll(users);
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Błąd ładowania użytkowników", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void refreshTable() {
        usersTableView.getItems().clear();
        try (Session session = sessionFactory.openSession()) {
            List<User> users = session.createQuery("FROM User", User.class).list();
            usersTableView.getItems().addAll(users);
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się odświeżyć tabeli użytkowników.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void openUserAddWindow() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/userAdd.fxml"));
            Parent root = loader.load();

            UserAddController userAddController = loader.getController();
            userAddController.setSessionFactory(sessionFactory);
            userAddController.setLoggedUser(loggedUser);

            Stage stage = new Stage();
            stage.initOwner(addUserButton.getScene().getWindow());
            stage.setTitle("Dodaj użytkownika");
            stage.setScene(new Scene(root));
            stage.setResizable(false);
            stage.showAndWait();
            refreshTable();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się otworzyć okna 'Dodaj użytkownika'.", Alert.AlertType.ERROR);
        }
    }

    private void openUserEditWindow() {
        User selectedUser = usersTableView.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            showAlert("Nie wybrano użytkownika", "Aby edytować, proszę wybrać użytkownika z tabeli.", Alert.AlertType.WARNING);
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/userEdit.fxml"));
            Parent root = loader.load();

            UserEditController userEditController = loader.getController();
            userEditController.setSessionFactory(sessionFactory);
            userEditController.setLoggedUser(loggedUser);
            userEditController.setUserToEdit(selectedUser);

            Stage stage = new Stage();
            stage.initOwner(editUserButton.getScene().getWindow());
            stage.setTitle("Edytuj użytkownika");
            stage.setScene(new Scene(root));
            stage.setResizable(false);
            stage.showAndWait();
            refreshTable();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się otworzyć okna 'Edytuj użytkownika'.", Alert.AlertType.ERROR);
        }
    }

    private void deleteUser() {
        User selectedUser = usersTableView.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            showAlert("Nie wybrano użytkownika", "Proszę wybrać użytkownika do usunięcia!", Alert.AlertType.WARNING);
            return;
        }

        if (selectedUser.getId().equals(loggedUser.getId())) {
            showAlert("Błąd", "Nie możesz usunąć siebie!", Alert.AlertType.ERROR);
            return;
        }

        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmationAlert.setTitle("Potwierdzenie usunięcia");
        confirmationAlert.setHeaderText(null);
        confirmationAlert.setContentText("Czy na pewno chcesz usunąć wybranego użytkownika?");
        ButtonType yesButton = new ButtonType("Tak", ButtonBar.ButtonData.YES);
        ButtonType noButton = new ButtonType("Nie", ButtonBar.ButtonData.NO);
        confirmationAlert.getButtonTypes().setAll(yesButton, noButton);

        confirmationAlert.showAndWait().ifPresent(response -> {
            if (response == yesButton) {
                try (Session session = sessionFactory.openSession()) {
                    Transaction transaction = session.beginTransaction();

                    session.delete(selectedUser);
                    transaction.commit();

                    usersList.remove(selectedUser);
                } catch (Exception e) {
                    e.printStackTrace();
                    showAlert("Error deleting user", e.getMessage(), Alert.AlertType.ERROR);
                }
            }
        });
    }

    @FXML
    private void goBackToDashboard() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/dashboard.fxml"));
            Parent dashboardRoot = loader.load();

            DashboardController dashboardController = loader.getController();
            dashboardController.setLoggedUser(loggedUser);

            Stage currentStage = (Stage) backToDashboard.getScene().getWindow();
            Scene dashboardScene = new Scene(dashboardRoot);
            currentStage.setScene(dashboardScene);
            currentStage.setTitle("Panel główny");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Nie udało się załadować widoku Dashboard.", Alert.AlertType.ERROR);
        }
    }
}