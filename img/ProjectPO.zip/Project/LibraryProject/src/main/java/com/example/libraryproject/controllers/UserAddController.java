package com.example.libraryproject.controllers;

import com.example.libraryproject.models.User;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import static com.example.libraryproject.utils.AlertUtil.showAlert;

public class UserAddController {

    @FXML
    private TextField usernameField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField passwordField;

    @FXML
    private Button addUserButton;

    @FXML
    private Button cancelButton;

    private SessionFactory sessionFactory;
    private User loggedUser;

    @FXML
    public void initialize() {
        addUserButton.setOnAction(event -> addUser());
        cancelButton.setOnAction(event -> closeWindow());
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public void setLoggedUser(User loggedUser) {
        this.loggedUser = loggedUser;
    }

    @FXML
    private void addUser() {
        String username = usernameField.getText();
        String email = emailField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            showAlert("Błąd", "Wszystkie pola muszą być wypełnione!", Alert.AlertType.ERROR);
            return;
        }


        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();

            User newUser = new User(username, email, password);
            session.save(newUser);

            transaction.commit();

            showAlert("Sukces", "Użytkownik został pomyślnie dodany!", Alert.AlertType.INFORMATION);
            closeWindow();
        } catch (Exception e) {
            showAlert("Błąd", "Wystąpił problem podczas dodawania użytkownika.", Alert.AlertType.ERROR);
            e.printStackTrace();
        }
    }

    @FXML
    private void closeWindow() {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }
}