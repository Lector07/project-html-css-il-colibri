package com.example.libraryproject.controllers;

import com.example.libraryproject.models.Author;
import com.example.libraryproject.models.User;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import static com.example.libraryproject.utils.AlertUtil.showAlert;

public class AuthorEditController {

    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private TextField countryField;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private SessionFactory sessionFactory;

    private User loggedUser;

    private Author authorToEdit;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public void setLoggedUser(User loggedUser) {
        this.loggedUser = loggedUser;
    }

    public void setAuthorToEdit(Author author) {
        this.authorToEdit = author;
        populateFields();
    }

    @FXML
    public void initialize() {
        saveButton.setOnAction(event -> updateAuthor());
        cancelButton.setOnAction(event -> closeWindow());
    }

    private void populateFields() {
        if (authorToEdit != null) {
            firstNameField.setText(authorToEdit.getFirstname());
            lastNameField.setText(authorToEdit.getLastname());
            countryField.setText(authorToEdit.getCountry());
        }
    }

    private void updateAuthor() {
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String country = countryField.getText();

        if (firstName.isEmpty() || lastName.isEmpty() || country.isEmpty()) {
            showAlert("Błąd", "Wszystkie pola muszą być wypełnione!", Alert.AlertType.WARNING);
            return;
        }

        // Walidacja formatu imienia i nazwiska
        if (!firstName.matches("[A-Z][a-zA-Z]*") || !lastName.matches("[A-Z][a-zA-Z]*")) {
            showAlert("Błąd", "Imię i nazwisko muszą zaczynać się wielką literą i zawierać tylko litery!", Alert.AlertType.WARNING);
            return;
        }

        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();

            authorToEdit.setFirstname(firstName);
            authorToEdit.setLastname(lastName);
            authorToEdit.setCountry(country);

            session.update(authorToEdit);
            transaction.commit();

            showAlert("Sukces", "Dane autora zostały zaktualizowane pomyślnie!", Alert.AlertType.INFORMATION);

            closeWindow();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się zaktualizować danych autora: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void closeWindow() {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }
}