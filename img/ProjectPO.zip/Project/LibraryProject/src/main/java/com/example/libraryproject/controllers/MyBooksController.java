package com.example.libraryproject.controllers;

import com.example.libraryproject.models.BorrowedBook;
import com.example.libraryproject.models.User;
import com.example.libraryproject.utils.AlertUtil;
import com.example.libraryproject.utils.HibernateUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.io.IOException;
import java.util.List;

import static com.example.libraryproject.utils.AlertUtil.showAlert;

public class MyBooksController {

    @FXML
    private Button backToDashboard;

    @FXML
    private TableView<BorrowedBook> myBooksTableView;

    @FXML
    private TableColumn<BorrowedBook, Long> idColumn;

    @FXML
    private TableColumn<BorrowedBook, String> titleColumn;

    @FXML
    private TableColumn<BorrowedBook, String> authorColumn;

    @FXML
    private TableColumn<BorrowedBook, String> borrowDateColumn;

    @FXML
    private TableColumn<BorrowedBook, String> returnDateColumn;

    private User loggedUser;

    @FXML
    public void initialize() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("bookTitle"));
        authorColumn.setCellValueFactory(new PropertyValueFactory<>("bookAuthor"));
        borrowDateColumn.setCellValueFactory(new PropertyValueFactory<>("borrowDate"));
        returnDateColumn.setCellValueFactory(new PropertyValueFactory<>("returnDate"));
    }

    public void setLoggedUser(User loggedUser) {
        this.loggedUser = loggedUser;
        loadMyBooks();
    }

    private void loadMyBooks() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            List<BorrowedBook> myBooks = session.createQuery("FROM BorrowedBook WHERE user = :user", BorrowedBook.class)
                    .setParameter("user", loggedUser)
                    .list();
            ObservableList<BorrowedBook> booksList = FXCollections.observableArrayList(myBooks);
            myBooksTableView.setItems(booksList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void returnBook() {
        BorrowedBook selectedBook = myBooksTableView.getSelectionModel().getSelectedItem();
        if (selectedBook == null) {
            AlertUtil.showAlert("Błąd", "Proszę wybrać książkę do oddania!", Alert.AlertType.ERROR);
            return;
        }

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();

            session.delete(selectedBook);

            selectedBook.getBook().setCopies(selectedBook.getBook().getCopies() + 1);
            session.update(selectedBook.getBook());

            transaction.commit();

            AlertUtil.showAlert("Sukces", "Książka została pomyślnie oddana!", Alert.AlertType.INFORMATION);
            loadMyBooks();
        } catch (Exception e) {
            e.printStackTrace();
            AlertUtil.showAlert("Błąd", "Wystąpił problem podczas oddawania książki.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void goBackToDashboard() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/dashboard.fxml"));
            Parent dashboardRoot = loader.load();

            DashboardController dashboardController = loader.getController();
            dashboardController.setLoggedUser(loggedUser);

            Stage currentStage = (Stage) backToDashboard.getScene().getWindow();
            Scene dashboardScene = new Scene(dashboardRoot);
            currentStage.setScene(dashboardScene);
            currentStage.setTitle("Panel główny");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się załadować widoku Dashboard.", Alert.AlertType.ERROR);
        }
    }
}