package com.example.libraryproject.controllers;

import com.example.libraryproject.models.User;
import com.example.libraryproject.utils.AlertUtil;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.io.IOException;

public class RegisterController {

    @FXML
    private TextField usernameField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField passwordField;

    @FXML
    private Button backToLoginButton;

    @FXML
    private Button registerButton;

    private SessionFactory sessionFactory;

    public RegisterController() {
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");
        configuration.addAnnotatedClass(User.class);

        sessionFactory = configuration.buildSessionFactory();
    }

    @FXML
    public void initialize() {
        registerButton.setOnAction(event -> registerUser());
        backToLoginButton.setOnAction(event -> backToLogin());
    }

    public void registerUser() {
        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String password = passwordField.getText().trim();

        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            AlertUtil.showAlert("Błąd walidacji", "Wszystkie pola są wymagane!", Alert.AlertType.WARNING);
            return;
        }

        if (username.contains(" ")) {
            AlertUtil.showAlert("Błąd walidacji", "Nazwa użytkownika nie może zawierać spacji!", Alert.AlertType.WARNING);
            return;
        }

        if (!email.contains("@")) {
            AlertUtil.showAlert("Błąd walidacji", "Zła konstrukcja adresu e-mail!", Alert.AlertType.WARNING);
            return;
        }

        if (!isValidPassword(password)) {
            AlertUtil.showAlert("Błąd walidacji", "Hasło musi zawierać co najmniej 8 znaków, w tym dużą literę, małą literę, cyfrę i znak specjalny!", Alert.AlertType.WARNING);
            return;
        }

        User user = new User(username, email, password);

        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();

            String query = "SELECT COUNT(u) FROM User u WHERE u.email = :email";
            Long count = (Long) session.createQuery(query)
                    .setParameter("email", email)
                    .uniqueResult();

            if (count > 0) {
                AlertUtil.showAlert("Błąd", "Użytkownik z takim adresem e-mail już istnieje!", Alert.AlertType.ERROR);
                transaction.rollback();
                return;
            }

            query = "SELECT COUNT(u) FROM User u WHERE u.username = :username";
            count = (Long) session.createQuery(query)
                    .setParameter("username", username)
                    .uniqueResult();

            if (count > 0) {
                AlertUtil.showAlert("Błąd", "Nazwa użytkownika jest zajęta!", Alert.AlertType.ERROR);
                transaction.rollback();
                return;
            }

            session.save(user);
            transaction.commit();
            AlertUtil.showAlert("Sukces", "Użytkownik został zarejestrowany pomyślnie!", Alert.AlertType.INFORMATION);
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
            AlertUtil.showAlert("Błąd", "Wystąpił błąd rejestracji: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private boolean isValidPassword(String password) {
        if (password.length() < 8) {
            return false;
        }
        boolean hasUppercase = false;
        boolean hasLowercase = false;
        boolean hasDigit = false;
        boolean hasSpecialChar = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasUppercase = true;
            } else if (Character.isLowerCase(c)) {
                hasLowercase = true;
            } else if (Character.isDigit(c)) {
                hasDigit = true;
            } else if (!Character.isLetterOrDigit(c)) {
                hasSpecialChar = true;
            }
        }
        return hasUppercase && hasLowercase && hasDigit && hasSpecialChar;
    }

    public void backToLogin() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/login.fxml"));
            Scene loginScene = new Scene(fxmlLoader.load());

            Stage stage = (Stage) backToLoginButton.getScene().getWindow();
            stage.setScene(loginScene);
            stage.setTitle("Logowanie");
        } catch (IOException e) {
            AlertUtil.showAlert("Błąd", "Nie można załadować ekranu logowania: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }
}