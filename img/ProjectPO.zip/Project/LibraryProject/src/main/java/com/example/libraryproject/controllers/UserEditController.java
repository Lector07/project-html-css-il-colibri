package com.example.libraryproject.controllers;

import com.example.libraryproject.models.User;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import static com.example.libraryproject.utils.AlertUtil.showAlert;

public class UserEditController {

    @FXML
    private TextField usernameField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField passwordField;

    @FXML
    private Button editUserButton;

    @FXML
    private Button cancelButton;

    private User userToEdit;
    private SessionFactory sessionFactory;
    private User loggedUser;

    @FXML
    public void initialize() {
        editUserButton.setOnAction(event -> editUser());
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public void setLoggedUser(User loggedUser) {
        this.loggedUser = loggedUser;
    }

    public void setUserToEdit(User user) {
        this.userToEdit = user;

        usernameField.setText(user.getUsername());
        emailField.setText(user.getEmail());
        passwordField.setText(user.getPassword());
    }

    private void editUser() {
        String username = usernameField.getText();
        String email = emailField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            showAlert("Błąd", "Wszystkie pola muszą być wypełnione!", Alert.AlertType.ERROR);
            return;
        }

        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();

            userToEdit.setUsername(username);
            userToEdit.setEmail(email);
            userToEdit.setPassword(password);

            session.update(userToEdit);

            transaction.commit();

            showAlert("Sukces", "Użytkownik został pomyślnie zaktualizowany!", Alert.AlertType.INFORMATION);
            closeWindow();
        } catch (Exception e) {
            showAlert("Błąd", "Wystąpił problem podczas aktualizowania użytkownika.", Alert.AlertType.ERROR);
            e.printStackTrace();
        }
    }

    @FXML
    private void closeWindow() {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }
}