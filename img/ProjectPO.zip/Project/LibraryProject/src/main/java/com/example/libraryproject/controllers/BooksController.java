package com.example.libraryproject.controllers;

import com.example.libraryproject.models.Book;
import com.example.libraryproject.models.User;
import com.example.libraryproject.utils.HibernateUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import static com.example.libraryproject.utils.AlertUtil.showAlert;

public class BooksController {

    @FXML
    private Button addBookButton;

    @FXML
    private Button updateBookButton;

    @FXML
    private Button deleteBookButton;

    @FXML
    private Button backToDashboard;

    private User loggedUser;

    @FXML
    private Label loggedUserLabel;

    @FXML
    private TableView<Book> booksTableView;

    @FXML
    private TableColumn<Book, Integer> columnId;

    @FXML
    private TableColumn<Book, String> columnTitle;

    @FXML
    private TableColumn<Book, String> columnAuthor;

    @FXML
    private TableColumn<Book, Integer> columnYear;

    @FXML
    private TableColumn<Book, Integer> columnCopies;

    private Book selectedBook;

    private SessionFactory sessionFactory;
    private ObservableList<Book> booksList;

    @FXML
    public void initialize() {
        try {
            setupHibernate();
            initializeTable();
            loadBooksFromDatabase();
            configureButtonActions();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Błąd inicjalizacji", "Wystąpił błąd podczas ładowania danych: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    public void setLoggedUser(User loggedUser) {
        this.loggedUser = loggedUser;
        updateLoggedUserLabel();
    }

    private void updateLoggedUserLabel() {
        if (loggedUser != null) {
            loggedUserLabel.setText("Zalogowany: " + loggedUser.getUsername());
        } else {
            loggedUserLabel.setText("User: Guest");
        }
    }

    private void setupHibernate() {
        this.sessionFactory = HibernateUtil.getSessionFactory();
    }

    private void initializeTable() {
        booksList = FXCollections.observableArrayList();
        booksTableView.setItems(booksList);

        columnId.setCellValueFactory(new PropertyValueFactory<>("id"));
        columnTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        columnAuthor.setCellValueFactory(new PropertyValueFactory<>("author"));
        columnYear.setCellValueFactory(new PropertyValueFactory<>("year"));
        columnCopies.setCellValueFactory(new PropertyValueFactory<>("copies"));
    }

    private void loadBooksFromDatabase() {
        try (Session session = sessionFactory.openSession()) {
            List<Book> books = session.createQuery("FROM Book", Book.class).list();
            booksList.setAll(books);
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się załadować listy książek.", Alert.AlertType.ERROR);
        }
    }

    private void refreshTable() {
        booksTableView.getItems().clear();
        loadBooksFromDatabase();
    }

    private void configureButtonActions() {
        addBookButton.setOnAction(event -> openBookAddWindow());
        updateBookButton.setOnAction(event -> openBookEditWindow());
        deleteBookButton.setOnAction(event -> deleteBookWithCopies());

        booksTableView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            selectedBook = newValue;
        });
    }

    @FXML
    private void openBookAddWindow() {
        openBookWindow("Dodaj książkę", "/com/example/libraryproject/views/bookAdd.fxml", null);
    }

    @FXML
    private void openBookEditWindow() {
        if (selectedBook == null) {
            showAlert("Błąd", "Proszę wybrać książkę do edycji.", Alert.AlertType.WARNING);
            return;
        }
        openBookWindow("Edycja książki", "/com/example/libraryproject/views/bookEdit.fxml", selectedBook);
    }

    private void openBookWindow(String title, String fxmlPath, Book bookToEdit) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent root = loader.load();

            if (fxmlPath.contains("bookEdit")) {
                BookEditController controller = loader.getController();
                controller.setSessionFactory(sessionFactory);
                controller.setBookToEdit(bookToEdit);
            }

            if (fxmlPath.contains("bookAdd")) {
                BookAddController controller = loader.getController();
                controller.setSessionFactory(sessionFactory);
            }

            Stage stage = new Stage();
            stage.initOwner(addBookButton.getScene().getWindow());
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.setResizable(false);
            stage.showAndWait();
            refreshTable();
        } catch (IOException e) {
            showAlert("Błąd", "Nie udało się otworzyć widoku: " + title, Alert.AlertType.ERROR);
            e.printStackTrace();
        }
    }

    private void deleteBookWithCopies() {
        if (selectedBook == null) {
            showAlert("Błąd", "Proszę wybrać książkę do usunięcia.", Alert.AlertType.WARNING);
            return;
        }

        if (selectedBook.getCopies() <= 1) {
            deleteBook(selectedBook);
        } else {
            TextInputDialog dialog = new TextInputDialog("1");
            dialog.setTitle("Usuń kopie książki");
            dialog.setHeaderText("Książka: " + selectedBook.getTitle());
            dialog.setContentText("Podaj liczbę kopii do usunięcia (maksymalnie " + selectedBook.getCopies() + "):");

            Optional<String> result = dialog.showAndWait();
            if (result.isPresent()) {
                try {
                    int copiesToRemove = Integer.parseInt(result.get());

                    if (copiesToRemove <= 0 || copiesToRemove > selectedBook.getCopies()) {
                        showAlert("Błąd", "Nieprawidłowa liczba kopii do usunięcia.", Alert.AlertType.WARNING);
                        return;
                    }

                    try (Session session = sessionFactory.openSession()) {
                        Transaction transaction = session.beginTransaction();
                        selectedBook.setCopies(selectedBook.getCopies() - copiesToRemove);
                        session.update(selectedBook);
                        transaction.commit();
                        refreshTable();
                    }
                } catch (NumberFormatException e) {
                    showAlert("Błąd", "Podaj poprawną liczbę kopii.", Alert.AlertType.ERROR);
                }
            }
        }
    }

    private void deleteBook(Book book) {
        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmationAlert.setTitle("Potwierdzenie usunięcia");
        confirmationAlert.setHeaderText(null);
        confirmationAlert.setContentText("Czy na pewno chcesz usunąć książkę \"" + book.getTitle() + "\"?");

        if (confirmationAlert.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            try (Session session = sessionFactory.openSession()) {
                Transaction transaction = session.beginTransaction();
                session.delete(book);
                transaction.commit();
                refreshTable();
            } catch (Exception e) {
                e.printStackTrace();
                showAlert("Błąd", "Nie udało się usunąć książki.", Alert.AlertType.ERROR);
            }
        }
    }

    @FXML
    private void goBackToDashboard() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/libraryproject/views/dashboard.fxml"));
            Parent dashboardRoot = loader.load();

            DashboardController dashboardController = loader.getController();
            dashboardController.setLoggedUser(loggedUser);

            Stage currentStage = (Stage) backToDashboard.getScene().getWindow();
            currentStage.setScene(new Scene(dashboardRoot));
            currentStage.setTitle("Panel główny");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się załadować widoku Dashboard.", Alert.AlertType.ERROR);
        }
    }
}