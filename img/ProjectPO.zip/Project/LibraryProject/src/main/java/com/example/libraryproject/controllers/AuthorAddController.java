package com.example.libraryproject.controllers;

import com.example.libraryproject.models.Author;
import com.example.libraryproject.models.User;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import static com.example.libraryproject.utils.AlertUtil.showAlert;

public class AuthorAddController {

    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private TextField countryField;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private SessionFactory sessionFactory;

    private User loggedUser;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public void setLoggedUser(User loggedUser) {
        this.loggedUser = loggedUser;
    }

    @FXML
    public void initialize() {
        saveButton.setOnAction(event -> saveAuthor());
        cancelButton.setOnAction(event -> closeWindow());
    }

    private void saveAuthor() {
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String country = countryField.getText();

        if (firstName.isEmpty() || lastName.isEmpty() || country.isEmpty()) {
            showAlert("Błąd", "Wszystkie pola muszą być wypełnione!", Alert.AlertType.WARNING);
            return;
        }

        if (!firstName.matches("[A-Z][a-zA-Z]*") || !lastName.matches("[A-Z][a-zA-Z]*")) {
            showAlert("Błąd", "Imię i nazwisko muszą zaczynać się wielką literą i zawierać tylko litery!", Alert.AlertType.WARNING);
            return;
        }

        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();

            Author author = new Author();
            author.setFirstname(firstName);
            author.setLastname(lastName);
            author.setCountry(country);

            session.save(author);
            transaction.commit();

            showAlert("Sukces", "Autor został dodany pomyślnie!", Alert.AlertType.INFORMATION);

            closeWindow();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się dodać autora: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void closeWindow() {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }
}