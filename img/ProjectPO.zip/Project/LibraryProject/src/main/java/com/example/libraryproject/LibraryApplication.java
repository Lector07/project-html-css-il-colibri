package com.example.libraryproject;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class LibraryApplication extends Application {

    private static Stage primaryStage;

    @Override
    public void start(Stage stage) throws Exception {
        primaryStage = stage;
        stage.setTitle("Biblioteka"); // Tytuł aplikacji
        changeScene("/com/example/libraryproject/views/login.fxml"); // Uruchomienie aplikacji z login.fxml
        stage.show();
    }

    public static void changeScene(String fxmlFilePath) {
        try {
            FXMLLoader loader = new FXMLLoader(LibraryApplication.class.getResource(fxmlFilePath));
            Parent root = loader.load();
            primaryStage.setScene(new Scene(root));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}